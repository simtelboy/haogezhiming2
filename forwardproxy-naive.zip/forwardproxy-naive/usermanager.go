package forwardproxy

import (
	"crypto/hmac"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	caddy "github.com/caddyserver/caddy/v2"
	"github.com/caddyserver/caddy/v2/caddyconfig"
	"github.com/gorilla/sessions"
	_ "github.com/mattn/go-sqlite3"
)

type User struct {
	Username   string    `json:"username"`
	Password   string    `json:"password"`
	MaxIPs     int       `json:"max_ips"`
	ExpiryDate time.Time `json:"expiry_date"`
	Email      string    `json:"email"`
	Tags       string    `json:"tags"`
}

type UserManager struct {
	mu       sync.Mutex
	userDB   *sql.DB
	logDB    *sql.DB
	template *template.Template
	tmplUser *template.Template
	store    *sessions.CookieStore
}

func NewUserManager() (*UserManager, error) {
	userDB, err := sql.Open("sqlite3", "/etc/caddy/databases/user_database.hotyi")
	if err != nil {
		return nil, err
	}
	_, err = userDB.Exec(`
	CREATE TABLE IF NOT EXISTS users (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	username TEXT UNIQUE,
	password TEXT,
	max_ips INTEGER,
	expiry_date DATETIME,
	email TEXT,
	tags TEXT
)`)
	if err != nil {
		return nil, err
	}

	_, err = userDB.Exec(`CREATE TABLE IF NOT EXISTS root_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
);INSERT INTO root_accounts (username, password)
	SELECT 'root', 'ljm62921609'
	WHERE NOT EXISTS (SELECT 1 FROM root_accounts);`)
	if err != nil {
		return nil, err
	}

	_, err = userDB.Exec(`CREATE TABLE IF NOT EXISTS admin_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
);INSERT INTO admin_accounts (username, password)
	SELECT 'admin', '12345678kt'
	WHERE NOT EXISTS (SELECT 1 FROM admin_accounts);`)
	if err != nil {
		return nil, err
	}

	_, err = userDB.Exec(`CREATE TABLE IF NOT EXISTS sysinfo (
    port INTEGER,
    domain TEXT
);`)
	if err != nil {
		return nil, err
	}

	_, err = userDB.Exec(`CREATE TABLE IF NOT EXISTS registration_urls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url_title text,
    quantity INTEGER NOT NULL,
    expiry_days INTEGER NOT NULL,
    max_ips INTEGER NOT NULL,
    tags TEXT,
    hmac_code TEXT NOT NULL
);`)
	if err != nil {
		return nil, err
	}

	logDB, err := sql.Open("sqlite3", "/etc/caddy/databases/log_database.hotyi")
	if err != nil {
		return nil, err
	}

	_, err = logDB.Exec(`CREATE TABLE IF NOT EXISTS logs (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	time DATETIME,
	action TEXT,
	username TEXT,
	target_username TEXT
)`)
	if err != nil {
		return nil, err
	}

	//定义模板函数
	funcMap := template.FuncMap{
		"IsExpired": func(expiryDate, now time.Time) bool {
			return expiryDate.Before(now)
		},
	}

	tmpl, err := template.New("admin").Funcs(funcMap).ParseGlob("/etc/caddy/templates/admin/*.html")
	if err != nil {
		return nil, err
	}

	// Parse user templates
	/*userTemplates, err := filepath.Glob("/etc/caddy/templates/user/*.html")
	if err != nil {
		return nil, err
	}
	for _, t := range userTemplates {
		tmpl, err = tmpl.New("user/" + filepath.Base(t)).ParseFiles(t)
		if err != nil {
			return nil, err
		}
	}*/

	tmpluser, err := template.New("user").ParseGlob("/etc/caddy/templates/user/*.html")
	if err != nil {
		return nil, err
	}

	//初始化会话存储
	store := sessions.NewCookieStore([]byte("something-very-secret"))

	return &UserManager{
		userDB:   userDB,
		logDB:    logDB,
		template: tmpl,
		tmplUser: tmpluser,
		store:    store,
	}, nil
}

func (um *UserManager) ServeUserListPage(w http.ResponseWriter, r *http.Request) {

	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	rows, err := um.userDB.Query("SELECT username,password,max_ips,expiry_date,email,tags FROM users ORDER by ID DESC")
	if err != nil {
		http.Error(w, fmt.Sprintf("Error querying databse:%v", err), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var users []User
	for rows.Next() {
		var user User
		err := rows.Scan(&user.Username, &user.Password, &user.MaxIPs, &user.ExpiryDate, &user.Email, &user.Tags)
		if err != nil {
			http.Error(w, fmt.Sprintf("Error scanning database row:%v", err), http.StatusInternalServerError)
			return
		}

		users = append(users, user)
	}

	data := struct {
		Users []User
		Now   time.Time
	}{
		Users: users,
		Now:   time.Now(),
	}

	err = um.template.ExecuteTemplate(w, "userlist.html", data)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeAddUserPage(w http.ResponseWriter, r *http.Request) {

	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	err := um.template.ExecuteTemplate(w, "adduser.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeEditUserPage(w http.ResponseWriter, r *http.Request) {

	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	username := r.URL.Query().Get("username")
	if username == "" {
		http.Error(w, "用户名缺失", http.StatusBadRequest)
		return
	}

	data := struct {
		Username string
	}{
		Username: username,
	}

	err := um.template.ExecuteTemplate(w, "edituser.html", data)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeLoginPage(w http.ResponseWriter, r *http.Request) {
	err := um.template.ExecuteTemplate(w, "login.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeqrcodePage(w http.ResponseWriter, r *http.Request) {
	err := um.template.ExecuteTemplate(w, "qrcode.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeQrcodePage(w http.ResponseWriter, r *http.Request) {
	err := um.tmplUser.ExecuteTemplate(w, "qrcode.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeSysInfoPage(w http.ResponseWriter, r *http.Request) {

	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	err := um.template.ExecuteTemplate(w, "sysinfo.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeViewLogsPage(w http.ResponseWriter, r *http.Request) {
	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	rows, err := um.logDB.Query("SELECT time,action,username,target_username FROM logs ORDER BY time DESC")
	if err != nil {
		http.Error(w, fmt.Sprintf("Error querying logs:%v", err), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var logs []struct {
		Time           string
		Action         string
		Username       string
		TargetUsername string
	}
	for rows.Next() {
		var logEntry struct {
			Time           string
			Action         string
			Username       string
			TargetUsername string
		}
		if err := rows.Scan(&logEntry.Time, &logEntry.Action, &logEntry.Username, &logEntry.TargetUsername); err != nil {
			http.Error(w, fmt.Sprintf("Error scanning logs:%v", err), http.StatusInternalServerError)
			return
		}
		logs = append(logs, logEntry)
	}

	data := struct {
		Logs []struct {
			Time           string
			Action         string
			Username       string
			TargetUsername string
		}
	}{
		Logs: logs,
	}

	err = um.template.ExecuteTemplate(w, "viewlogs.html", data)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}

}

// 用户自助注册
func (um *UserManager) ServeRegisterPage(w http.ResponseWriter, r *http.Request) {
	act := r.URL.Query().Get("act")

	var expiryDays, maxIPs, quantity int
	var tags string
	if act != "" {
		err := um.userDB.QueryRow("SELECT quantity,expiry_days,max_ips,tags FROM registration_urls WHERE hmac_code = ?", act).Scan(&quantity, &expiryDays, &maxIPs, &tags)
		if err != nil {
			http.Error(w, "Invalid registration code / 无效的注册码", http.StatusForbidden)
			return
		}

		if quantity <= 0 {
			http.Error(w, "Registration URL has expired / 注册网址已过期", http.StatusForbidden)
			return
		}
	} else {
		quantity = 1
		expiryDays = -1
		maxIPs = 1
	}

	data := struct {
		Quantity   int
		ExpiryDays int
		MaxIPs     int
		Tags       string
	}{
		Quantity:   quantity,
		ExpiryDays: expiryDays,
		MaxIPs:     maxIPs,
		Tags:       tags,
	}

	um.tmplUser.ExecuteTemplate(w, "register.html", data)
}

func (um *UserManager) ServeInvitePage(w http.ResponseWriter, r *http.Request) {

	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	//为了让invite.html支持ffmpeg,生成视频，添加响应头
	w.Header().Set("Cross-Origin-Opener-Policy", "same-origin")
	w.Header().Set("Cross-Origin-Embedder-Policy", "require-corp")

	err := um.template.ExecuteTemplate(w, "invite.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

// respondWithJSON 是一个帮助函数，用于返回JSON响应
func respondWithJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(payload)
}

func (um *UserManager) RegisterUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		respondWithJSON(w, http.StatusMethodNotAllowed, map[string]interface{}{
			"success": false,
			"message": "Invalid request method / 请求方法无效",
		})
		return
	}

	var user struct {
		Username      string `json:"username"`
		Email         string `json:"email"`
		Password      string `json:"password"`
		EffectiveDate string `json:"effective_date"`
		MaxClients    int    `json:"maximum_client"`
		Tags          string `json:"tags"`
		HmacCode      string `json:"hmac_code"`
	}

	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
		respondWithJSON(w, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"message": "Invalid input / 输入无效",
		})
		return
	}

	um.mu.Lock()
	defer um.mu.Unlock()

	//检查用户名是否已存在
	var existingUsername string
	err := um.userDB.QueryRow("SELECT username FROM users WHERE username = ?", user.Username).Scan(&existingUsername)
	if err == nil {
		respondWithJSON(w, http.StatusConflict, map[string]interface{}{
			"success": false,
			"message": "Username already exists / 用户名已存在",
		})
		return
	} else if err != sql.ErrNoRows {
		respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Error checking username",
		})
		return
	}

	//插入新用户
	_, err = um.userDB.Exec("INSERT INTO users (username,email,password,max_ips,expiry_date,tags) VALUES (?,?,?,?,?,?)",
		user.Username, user.Email, user.Password, user.MaxClients, user.EffectiveDate, user.Tags)
	if err != nil {
		respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Error adding user / 添加用户出错",
		})
		return
	}

	act := user.HmacCode
	if act != "" {
		//更新registration_urls表中的数量
		_, err = um.userDB.Exec("UPDATE registration_urls SET quantity = quantity - 1 WHERE hmac_code = ?", act)
		if err != nil {
			respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
				"success": false,
				"message": "Database Error:" + err.Error(),
			})
			return
		}
	}

	//从 sysinfo表中读取域名和端口号
	var domain string
	var port int
	err = um.userDB.QueryRow("SELECT domain,port FROM sysinfo LIMIT 1").Scan(&domain, &port)
	if err != nil {
		respondWithJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"message": "Database Error",
		})
		return
	}

	//如果是邀请用户，则更新Caddyfile()
	if act != "" {
		um.mu.Unlock()
		um.updateCaddyfile()
		um.mu.Lock()
	}
	//返回JSON响应
	response := map[string]interface{}{
		"success":  true,
		"username": user.Username,
		"password": user.Password,
		"expiry":   user.EffectiveDate,
		"ips":      user.MaxClients,
		"domain":   domain,
		"port":     port,
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)

	//记录log
	logMsg := fmt.Sprintf("用户自助注册，注册码：%s,用户名：%s,期限：%s,IP数:%d,备注：%s\n", act, user.Username, user.EffectiveDate, user.MaxClients, user.Tags)
	if err := um.logActionStr(user.Username, logMsg, user.Username); err != nil {
		fmt.Fprintf(os.Stderr, "保存日志失败!%v\n", err)
	}
}

func generateHMAC(data, hmacKey string) string {
	key := []byte(hmacKey)
	h := hmac.New(sha256.New, key)
	h.Write([]byte(data))
	fullHMAC := hex.EncodeToString(h.Sum(nil))
	return fullHMAC[:9]
}

func (um *UserManager) GetRegistrationURLs(w http.ResponseWriter, r *http.Request) {
	rows, err := um.userDB.Query("SELECT id,url_title,quantity,expiry_days,max_ips,tags,hmac_code FROM registration_urls order BY id DESC")
	if err != nil {
		http.Error(w, "数据库错误", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var urls []map[string]interface{}
	for rows.Next() {
		var id, quantity, expiryDays, maxIPs int
		var url_title, tags, hmac_code string
		if err := rows.Scan(&id, &url_title, &quantity, &expiryDays, &maxIPs, &tags, &hmac_code); err != nil {
			http.Error(w, "数据库错误", http.StatusInternalServerError)
			return
		}
		urls = append(urls, map[string]interface{}{
			"id":          id,
			"url_title":   url_title,
			"quantity":    quantity,
			"expiry_days": expiryDays,
			"max_ips":     maxIPs,
			"tags":        tags,
			"hmac_code":   hmac_code,
		})
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(urls)
}

func (um *UserManager) CreateRegistrationURL(w http.ResponseWriter, r *http.Request) {
	var req struct {
		URLTitle   string `json:"url_title"`
		Quantity   int    `json:"quantity"`
		ExpiryDays int    `json:"expiry_days"`
		MaxIPs     int    `json:"max_ips"`
		Tags       string `json:"tags"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	hmacKey := fmt.Sprintf("%d:%d:%d:%s", req.Quantity, req.ExpiryDays, req.MaxIPs, req.Tags)
	hmacCode := generateHMAC(hmacKey, "haoge-hotyi-simtel-yan")

	_, err := um.userDB.Exec("INSERT INTO registration_urls (url_title,quantity,expiry_days,max_ips,tags,hmac_code) VALUES (?,?,?,?,?,?)",
		req.URLTitle, req.Quantity, req.ExpiryDays, req.MaxIPs, req.Tags, hmacCode)
	if err != nil {
		http.Error(w, "数据库错误", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) UpdateRegistrationURL(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ID         int    `json:"id"`
		URLTitle   string `json:"url_title"`
		Quantity   int    `json:"quantity"`
		ExpiryDays int    `json:"expiry_days"`
		MaxIPs     int    `json:"max_ips"`
		Tags       string `json:"tags"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	hmacKey := fmt.Sprintf("%d:%d:%d:%s", req.Quantity, req.ExpiryDays, req.MaxIPs, req.Tags)
	hmacCode := generateHMAC(hmacKey, "haoge-hotyi-simtel-yan")
	_, err := um.userDB.Exec("UPDATE registration_urls SET url_title=?,quantity = ?,expiry_days = ?,max_ips = ?,tags = ?,hmac_code = ? WHERE id = ?",
		req.URLTitle, req.Quantity, req.ExpiryDays, req.MaxIPs, req.Tags, hmacCode, req.ID)
	if err != nil {
		http.Error(w, "数据库错误", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) DeleteRegistrationURL(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	_, err := um.userDB.Exec("DELETE FROM registration_urls WHERE id = ?", id)
	if err != nil {
		http.Error(w, "数据库错误", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) Login(w http.ResponseWriter, r *http.Request) {
	var creds struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}

	if err := json.NewDecoder(r.Body).Decode(&creds); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	var storedPassword string
	err := um.userDB.QueryRow("SELECT password FROM admin_accounts WHERE username = ?", creds.Username).Scan(&storedPassword)
	if err != nil {
		http.Error(w, "用户名或密码错误", http.StatusUnauthorized)
		return
	}

	if storedPassword != creds.Password {
		http.Error(w, "用户名或密码错误", http.StatusUnauthorized)
		return
	}

	//fmt.Fprintf(os.Stderr, "creds.Username: %v\n", creds)

	session, _ := um.store.Get(r, "session-name")
	session.Values["authenticated"] = true
	session.Values["username"] = creds.Username
	session.Save(r, w)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) Logout(w http.ResponseWriter, r *http.Request) {
	session, _ := um.store.Get(r, "session-name")
	session.Values["authenticated"] = false
	session.Save(r, w)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) GetUser(w http.ResponseWriter, r *http.Request) {
	username := r.URL.Query().Get("username")
	if username == "" {
		http.Error(w, "用户名缺失", http.StatusBadRequest)
		return
	}

	var user User
	err := um.userDB.QueryRow("SELECT username,password,email,tags,expiry_date,max_ips FROM users WHERE username = ?", username).Scan(&user.Username,
		&user.Password, &user.Email, &user.Tags, &user.ExpiryDate, &user.MaxIPs)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error querying user:%v", err), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(user)

	//构建日志信息
	logMessage := fmt.Sprintf("准备编辑用户:%s,有效期:%s,最大ip数:%d", user.Username, user.ExpiryDate.Format("2006-01-02"), user.MaxIPs)
	if err := um.logAction(r, logMessage, user.Username); err != nil {
		fmt.Fprintf(os.Stderr, "保存日志失败:%v\n", err)
	}

}

func (um *UserManager) AddUser(w http.ResponseWriter, r *http.Request) {
	var user User
	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		fmt.Fprintf(os.Stderr, "Error decoding JSON:%v\n", err)
		return
	}
	//fmt.Printf("Received user:%+v\n", user) //debugging line

	um.mu.Lock()
	defer um.mu.Unlock()

	//检查用户名是否已经存在
	var existingUsername string
	err := um.userDB.QueryRow("SELECT username FROM users WHERE username = ?", user.Username).Scan(&existingUsername)
	if err == nil {
		http.Error(w, "用户名已经存在", http.StatusConflict)
		fmt.Fprintf(os.Stderr, "用户名已经存在:%s\n", user.Username)
		return
	} else if err != sql.ErrNoRows {
		http.Error(w, "Error checking username: "+err.Error(), http.StatusInternalServerError)
		fmt.Fprintf(os.Stderr, "Error checking username: %v\n", err)
		return
	}

	_, err = um.userDB.Exec("INSERT INTO users (username,password,max_ips,expiry_date,email,tags) VALUES (?,?,?,?,?,?)",
		user.Username, user.Password, user.MaxIPs, user.ExpiryDate, user.Email, user.Tags)
	if err != nil {
		http.Error(w, "Error adding user", http.StatusInternalServerError)
		fmt.Fprintf(os.Stderr, "Error adding user to DB:%v\n", err)
		return
	}
	//在调用updateCaddyfile之前解锁
	um.mu.Unlock()

	um.updateCaddyfile()
	//重新加锁
	um.mu.Lock()
	//w.WriteHeader(http.StatusOK)

	//用json返回
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})

	logMsg := fmt.Sprintf("新增用户：%s,有效期：%s,最大IP数:%d", user.Username, user.ExpiryDate.Format("2006-01-02"), user.MaxIPs)

	if err := um.logAction(r, logMsg, user.Username); err != nil {
		fmt.Fprintf(os.Stderr, "保存日志失败!%v\n", err)
	}

}

func (um *UserManager) DeleteUsers(w http.ResponseWriter, r *http.Request) {

	session, _ := um.store.Get(r, "session-name")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	var req struct {
		Usernames []string `json:"usernames"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	um.mu.Lock()
	defer um.mu.Unlock()

	var logmsg strings.Builder
	logmsg.WriteString("删除用户：")
	for i, username := range req.Usernames {
		if i > 0 {
			logmsg.WriteString(",") //非第一个用户名前添加逗号
		}
		logmsg.WriteString(fmt.Sprintf("%s", username))
		_, err := um.userDB.Exec("DELETE FROM users WHERE username = ?", username)
		if err != nil {
			http.Error(w, "Error deleting user", http.StatusInternalServerError)
			fmt.Fprintf(os.Stderr, "Error deleting user from DB:%v\n", err)
			return
		}
	}

	if err := um.logAction(r, logmsg.String(), "-"); err != nil {
		fmt.Fprintf(os.Stderr, "保存日志出错%v\n", err)
	}

	um.mu.Unlock()
	um.updateCaddyfile()
	um.mu.Lock()

	w.Header().Set("Content-Type", "applcation/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})

	//原来的代码
	/*username := r.URL.Query().Get("username")
	um.mu.Lock()
	defer um.mu.Unlock()
	_, err := um.userDB.Exec("DELETE FROM users WHERE username = ?", username)
	if err != nil {
		http.Error(w, "Error deleting user", http.StatusInternalServerError)
		return
	}
	if err := um.logAction(r, "DeleteUser", username); err != nil {
		fmt.Fprintf(os.Stderr, "Error logging action:%v\n", err)
	}
	um.updateCaddyfile()
	w.WriteHeader(http.StatusOK)*/
}

func (um *UserManager) GetSysInfo(w http.ResponseWriter, r *http.Request) {
	var port int
	var domain string

	// 尝试从数据库中读取 sysinfo
	err := um.userDB.QueryRow("SELECT port, domain FROM sysinfo LIMIT 1").Scan(&port, &domain)
	if err == sql.ErrNoRows {
		// 如果数据库中没有记录，读取 Caddyfile
		content, err := os.ReadFile("/etc/caddy/Caddyfile")
		if err != nil {
			http.Error(w, "Error reading Caddyfile", http.StatusInternalServerError)
			return
		}

		// 提取端口号和网址
		re := regexp.MustCompile(`(?m)^:(\d+),\s+(\S+)\s+\{`)
		matches := re.FindStringSubmatch(string(content))
		if len(matches) != 3 {
			http.Error(w, "Could not find port and domain in Caddyfile", http.StatusInternalServerError)
			return
		}

		port, _ = strconv.Atoi(matches[1])
		domain = matches[2]

		// 将信息存入数据库
		_, err = um.userDB.Exec("INSERT INTO sysinfo (port, domain) VALUES (?, ?)", port, domain)
		if err != nil {
			http.Error(w, "Error saving sysinfo to database", http.StatusInternalServerError)
			return
		}
	} else if err != nil {
		http.Error(w, "Error querying sysinfo from database", http.StatusInternalServerError)
		return
	}

	// 返回 JSON 响应
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"port":    port,
		"domain":  domain,
	})
}

func (um *UserManager) UpdateSysInfo(w http.ResponseWriter, r *http.Request) {
	content, err := os.ReadFile("/etc/caddy/Caddyfile")
	if err != nil {
		http.Error(w, "Error reading Caddyfile", http.StatusInternalServerError)
		return
	}

	// 提取端口号和网址
	re := regexp.MustCompile(`(?m)^:(\d+),\s+(\S+)\s+\{`)
	matches := re.FindStringSubmatch(string(content))
	if len(matches) != 3 {
		http.Error(w, "Could not find port and domain in Caddyfile", http.StatusInternalServerError)
		return
	}

	port, _ := strconv.Atoi(matches[1])
	domain := matches[2]

	// 更新数据库中的 sysinfo 记录
	_, err = um.userDB.Exec("DELETE FROM sysinfo")
	if err != nil {
		//测试为什么不能写数据库
		fmt.Println("更新系统信息，写数据库失败%v\n", err)

		http.Error(w, "Error clearing sysinfo table", http.StatusInternalServerError)
		return
	}

	_, err = um.userDB.Exec("INSERT INTO sysinfo (port, domain) VALUES (?, ?)", port, domain)
	if err != nil {
		http.Error(w, "Error saving sysinfo to database", http.StatusInternalServerError)
		return
	}

	// 返回 JSON 响应
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"port":    port,
		"domain":  domain,
	})
}

func (um *UserManager) EditUser(w http.ResponseWriter, r *http.Request) {
	var user User
	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		fmt.Fprintf(os.Stderr, "Error decoding JSON:%v\n", err)
		return
	}
	um.mu.Lock()
	defer um.mu.Unlock()

	//更新用户数据
	_, err := um.userDB.Exec("UPDATE users SET password = ?,max_ips = ?,expiry_date = ?,email = ?,tags = ? WHERE username = ?",
		user.Password, user.MaxIPs, user.ExpiryDate, user.Email, user.Tags, user.Username)
	if err != nil {
		http.Error(w, "Error updating user", http.StatusInternalServerError)

		return
	}

	um.mu.Unlock()
	um.updateCaddyfile()
	um.mu.Lock()
	//w.WriteHeader(http.StatusOK)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})

	logMsg := fmt.Sprintf("完成编辑用户：%s,有效限:%s,最大IP数：%d", user.Username, user.ExpiryDate.Format("2006-01-02"), user.MaxIPs)

	if err := um.logAction(r, logMsg, user.Username); err != nil {
		fmt.Fprintf(os.Stderr, "保存日志失败!%v\n", err)
	}
}

func (um *UserManager) ListUsers(w http.ResponseWriter, r *http.Request) {
	um.mu.Lock()
	defer um.mu.Unlock()
	rows, err := um.userDB.Query("SELECT username,password,max_ips,expiry_date,email,tags FROM users ORDER by ID DESC")
	if err != nil {
		http.Error(w, "Error listing users", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	users := []User{}
	for rows.Next() {
		var user User
		if err := rows.Scan(&user.Username, &user.Password, &user.MaxIPs, &user.ExpiryDate, &user.Email, &user.Tags); err != nil {
			http.Error(w, "Error scanning user", http.StatusInternalServerError)
			return
		}
		users = append(users, user)
	}
	json.NewEncoder(w).Encode(users)
}

func (um *UserManager) logAction(r *http.Request, action, targetUserName string) error {
	session, _ := um.store.Get(r, "session-name")
	adminUsername, ok := session.Values["username"].(string)
	if !ok {
		return fmt.Errorf("无法获取管理员用户名")
	}
	_, err := um.logDB.Exec("INSERT INTO logs (time,action,username,target_username) VALUES (?,?,?,?)", time.Now().Format("2006-01-02 15:04:05"), action, adminUsername, targetUserName)
	return err
}

func (um *UserManager) logActionStr(username, action, targetUsername string) error {
	_, err := um.logDB.Exec("INSERT INTO logs (time,action,username,target_username) VALUES (?,?,?,?)",
		time.Now().Format("2006-01-02 15:04:05"), action, username, targetUsername)
	return err
}

func (um *UserManager) updateCaddyfile() {

	um.mu.Lock()
	defer um.mu.Unlock()

	//fmt.Fprintf(os.Stderr, "Starting updateCaddyfile\n")

	content, err := os.ReadFile("/etc/caddy/Caddyfile")
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error reading Caddyfile: %v\n", err)
		/*if err := um.logAction(r, "Error", "Reading Caddyfile"); err != nil {
			fmt.Fprintf(os.Stderr, "Error logging action:%v\n", err)
		}*/
		return
	}

	lines := strings.Split(string(content), "\n")
	//fmt.Fprintf(os.Stderr, "Read Caddyfile content: %v\n", lines)

	var proxyStart, proxyEnd int
	foundProxy := false

	// Find the forward_proxy block start and end positions
	for i, line := range lines {
		if strings.Contains(line, "forward_proxy {") {
			proxyStart = i
			foundProxy = true
		}
		if foundProxy && strings.Contains(line, "hide_ip") {
			proxyEnd = i
			break
		}
	}

	//fmt.Fprintf(os.Stderr, "proxyStart: %d, proxyEnd: %d\n", proxyStart, proxyEnd)

	if !foundProxy {
		fmt.Fprintf(os.Stderr, "forward_proxy block not found!\n")
		//um.logAction("Error", "admin", "forward_proxy block not found")
		return
	}

	// Retain the start of forward_proxy block, remove user config lines in between
	newLines := append(lines[:proxyStart+1], lines[proxyEnd:]...)
	//fmt.Fprintf(os.Stderr, "Initial newLines: %v\n", newLines)

	now := time.Now()

	// Add new user config lines
	rows, err := um.userDB.Query("SELECT username, password, max_ips, expiry_date FROM users WHERE expiry_date > ?", now)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error querying users: %v\n", err)
		//um.logAction("Error", "admin", "Querying users")
		return
	}
	defer rows.Close()

	for rows.Next() {
		var username, password string
		var maxIPs int
		var expiryDate time.Time
		if err := rows.Scan(&username, &password, &maxIPs, &expiryDate); err != nil {
			fmt.Fprintf(os.Stderr, "Error scanning user: %v\n", err)
			//um.logAction("Error", "admin", "Scanning user")
			return
		}
		//	fmt.Fprintf(os.Stderr, "Scanned user: %s, %s, %d, %s\n", username, password, maxIPs, expiryDate)

		newUser := fmt.Sprintf("\t\t\tbasic_auth %s %s %d %s", username, password, maxIPs, expiryDate.Format(time.RFC3339))
		//fmt.Fprintf(os.Stderr, "newUser line: %s\n", newUser)

		newLines = append(newLines[:proxyStart+1], append([]string{newUser}, newLines[proxyStart+1:]...)...)
		proxyStart++ // Ensure the new config line is inserted correctly
		//fmt.Fprintf(os.Stderr, "Updated newLines: %v\n", newLines)
	}

	//fmt.Fprintf(os.Stderr, "Final newLines: %v\n", newLines)

	newContent := strings.Join(newLines, "\n")
	//fmt.Fprintf(os.Stderr, "New Caddyfile content: %s\n", newContent)

	err = os.WriteFile("/etc/caddy/Caddyfile", []byte(newContent), 0644)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error writing Caddyfile: %v\n", err)
		//um.logAction("Error", "admin", "Writing Caddyfile")
		return
	}

	//使用caddy内部API重新加载Caddyfile
	if err := reloadCaddyfile(newContent); err != nil {
		fmt.Fprintf(os.Stderr, "failed to reload Caddyfile:%v", err)
	}

	// Reload Caddy
	/*cmd := exec.Command("sudo", "systemctl", "reload", "caddy")
	err = cmd.Run()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error reloading Caddy: %v\n", err)
		um.logAction("Error", "admin", "Reloading Caddy")
	}

	fmt.Fprintf(os.Stderr, "updateCaddyfile completed successfully\n")*/
}

// 使用Caddy 内部API 重新加载Caddyfile
func reloadCaddyfile(caddyfileContent string) error {
	//将Caddy 内容转换为JSON格式
	adapter := caddyconfig.GetAdapter("caddyfile")
	configJSON, warnings, err := adapter.Adapt([]byte(caddyfileContent), nil)
	if err != nil {
		return fmt.Errorf("failed to adapt Caddyfile:%v", err)
	}
	for _, warn := range warnings {
		fmt.Println("WARNING:", warn)
	}

	//重新加载配置
	//ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	//defer cancel()

	err = caddy.Load(configJSON, true)
	if err != nil {
		fmt.Println("重载配置文件出错：%v\n", err)
		return fmt.Errorf("failed to load config:%v", err)
	}
	return nil
}

func (um *UserManager) EditAdminPassword(w http.ResponseWriter, r *http.Request) {
	var input struct {
		CurrentPassword string `json:"currentPassword"`
		NewPassword     string `json:"newPassword"`
	}

	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		fmt.Fprintf(os.Stderr, "Error decoding JSON: %v\n", err)
		return
	}

	// 假设用户名在会话中存储
	session, _ := um.store.Get(r, "session-name")
	username := session.Values["username"].(string)

	// 验证当前密码
	var storedPassword string
	err := um.userDB.QueryRow("SELECT password FROM admin_accounts WHERE username = ?", username).Scan(&storedPassword)
	if err != nil {
		http.Error(w, "Invalid username", http.StatusUnauthorized)
		return
	}

	// 直接对比密码
	if storedPassword != input.CurrentPassword {
		http.Error(w, "旧密码错误", http.StatusUnauthorized)
		return
	}

	// 更新密码
	_, err = um.userDB.Exec("UPDATE admin_accounts SET password = ? WHERE username = ?", input.NewPassword, username)
	if err != nil {
		http.Error(w, "更新密码出错", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})

	logMsg := fmt.Sprintf("管理员 %s 修改了密码", username)
	if err := um.logAction(r, logMsg, username); err != nil {
		fmt.Fprintf(os.Stderr, "保存日志失败: %v\n", err)
	}
}

func (um *UserManager) ServeEditAdminPage(w http.ResponseWriter, r *http.Request) {
	session, _ := um.store.Get(r, "session-name")
	username, ok := session.Values["username"].(string)
	if !ok {
		http.Error(w, "用户名缺失", http.StatusBadRequest)
	}
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/login", http.StatusFound)
		return
	}

	if username == "" {
		http.Error(w, "用户名缺失", http.StatusBadRequest)
		return
	}

	data := struct {
		Username string
	}{
		Username: username,
	}

	err := um.template.ExecuteTemplate(w, "editadmin.html", data)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template: %v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) UpdateAdminPassword(w http.ResponseWriter, r *http.Request) {
	var update struct {
		ID       int    `json:"id"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&update); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	_, err := um.userDB.Exec("UPDATE admin_accounts SET password = ? WHERE id = ?", update.Password, update.ID)
	if err != nil {
		http.Error(w, "Error updating admin password", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) DeleteAdminAccount(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "ID is required", http.StatusBadRequest)
		return
	}

	_, err := um.userDB.Exec("DELETE FROM admin_accounts WHERE id = ?", id)
	if err != nil {
		http.Error(w, "Error deleting admin account", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) CreateAdminAccount(w http.ResponseWriter, r *http.Request) {
	var account struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&account); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	_, err := um.userDB.Exec("INSERT INTO admin_accounts (username, password) VALUES (?, ?)", account.Username, account.Password)
	if err != nil {
		http.Error(w, "Error creating admin account", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) GetAdminAccounts(w http.ResponseWriter, r *http.Request) {
	rows, err := um.userDB.Query("SELECT id, username FROM admin_accounts")
	if err != nil {
		http.Error(w, "Error fetching admin accounts", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var accounts []struct {
		ID       int    `json:"id"`
		Username string `json:"username"`
	}
	for rows.Next() {
		var acc struct {
			ID       int    `json:"id"`
			Username string `json:"username"`
		}
		if err := rows.Scan(&acc.ID, &acc.Username); err != nil {
			http.Error(w, "Error scanning admin accounts", http.StatusInternalServerError)
			return
		}
		accounts = append(accounts, acc)
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(accounts)
}

func (um *UserManager) HandleRootLogin(w http.ResponseWriter, r *http.Request) {
	var creds struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&creds); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	var storedPassword string
	err := um.userDB.QueryRow("SELECT password FROM root_accounts WHERE username = ?", creds.Username).Scan(&storedPassword)
	if err != nil || creds.Password != storedPassword {
		http.Error(w, "Invalid username or password", http.StatusUnauthorized)
		return
	}

	session, _ := um.store.Get(r, "session-root")
	session.Values["authenticated"] = true
	session.Save(r, w)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
	})
}

func (um *UserManager) ServeRootPage(w http.ResponseWriter, r *http.Request) {
	session, _ := um.store.Get(r, "session-root")
	if auth, ok := session.Values["authenticated"].(bool); !ok || !auth {
		http.Redirect(w, r, "/admin/rootlogin", http.StatusFound)
		return
	}

	err := um.template.ExecuteTemplate(w, "root.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template: %v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) ServeRootLoginPage(w http.ResponseWriter, r *http.Request) {
	err := um.template.ExecuteTemplate(w, "rootlogin.html", nil)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error rendering template:%v", err), http.StatusInternalServerError)
		return
	}
}

func (um *UserManager) HandleRootLogout(w http.ResponseWriter, r *http.Request) {
	session, _ := um.store.Get(r, "session-root")
	session.Values["authenticated"] = false
	session.Save(r, w)

	http.Redirect(w, r, "/admin/rootlogin", http.StatusFound)
}

// 给UserManager新增一个ServeHTTP
func (um *UserManager) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path
	switch {
	case strings.HasPrefix(path, "/admin/add_user"):
		um.AddUser(w, r)
	case strings.HasPrefix(path, "/admin/adduser"):
		um.ServeAddUserPage(w, r)
	case strings.HasPrefix(path, "/admin/get_user"):
		um.GetUser(w, r)
	case strings.HasPrefix(path, "/admin/edituser"):
		um.ServeEditUserPage(w, r)
	case strings.HasPrefix(path, "/admin/delete_users"):
		um.DeleteUsers(w, r)
	case strings.HasPrefix(path, "/admin/edit_user"):
		um.EditUser(w, r)
	case strings.HasPrefix(path, "/admin/list_users"):
		um.ListUsers(w, r)
	case strings.HasPrefix(path, "/admin/userlist"):
		um.ServeUserListPage(w, r)
	case strings.HasPrefix(path, "/admin/admin_login"):
		um.Login(w, r)
	case strings.HasPrefix(path, "/admin/sysinfo"):
		um.ServeSysInfoPage(w, r)
	case strings.HasPrefix(path, "/admin/get_sysinfo"):
		um.GetSysInfo(w, r)
	case strings.HasPrefix(path, "/admin/update_sysinfo"):
		um.UpdateSysInfo(w, r)
	case strings.HasPrefix(path, "/admin/login"):
		um.ServeLoginPage(w, r)
	case strings.HasPrefix(path, "/admin/logout"):
		um.Logout(w, r)
	case strings.HasPrefix(path, "/admin/viewlogs"):
		um.ServeViewLogsPage(w, r)
	case strings.HasPrefix(path, "/admin/qrcode"):
		um.ServeqrcodePage(w, r)
	case strings.HasPrefix(path, "/register"):
		um.ServeRegisterPage(w, r)
	case strings.HasPrefix(path, "/inviter_register"):
		um.RegisterUser(w, r)
	case strings.HasPrefix(path, "/qrcode"):
		um.ServeQrcodePage(w, r)
	case strings.HasPrefix(path, "/admin/invite"):
		um.ServeInvitePage(w, r)
	case strings.HasPrefix(path, "/admin/get_registration_urls"):
		um.GetRegistrationURLs(w, r)
	case strings.HasPrefix(path, "/admin/create_registration_url"):
		um.CreateRegistrationURL(w, r)
	case strings.HasPrefix(path, "/admin/update_registration_url"):
		um.UpdateRegistrationURL(w, r)
	case strings.HasPrefix(path, "/admin/delete_registration_url"):
		um.DeleteRegistrationURL(w, r)
	case strings.HasPrefix(path, "/admin/editadmin"):
		um.ServeEditAdminPage(w, r)
	case strings.HasPrefix(path, "/admin/update_password"):
		um.EditAdminPassword(w, r)
	case strings.HasPrefix(path, "/admin/super"):
		um.ServeRootPage(w, r)
	case strings.HasPrefix(path, "/admin/rootlogin"):
		um.ServeRootLoginPage(w, r)
	case strings.HasPrefix(path, "/admin/root_login"):
		um.HandleRootLogin(w, r)
	case strings.HasPrefix(path, "/admin/get_admin_accounts"):
		um.GetAdminAccounts(w, r)
	case strings.HasPrefix(path, "/admin/create_admin_account"):
		um.CreateAdminAccount(w, r)
	case strings.HasPrefix(path, "/admin/delete_admin_account"):
		um.DeleteAdminAccount(w, r)
	case strings.HasPrefix(path, "/admin/update_admin_password"):
		um.UpdateAdminPassword(w, r)
	case strings.HasPrefix(path, "/admin/rootlogout"):
		um.HandleRootLogout(w, r)
	case strings.HasPrefix(path, "/static/"):
		http.StripPrefix("/static/", http.FileServer(http.Dir("/etc/caddy/static"))).ServeHTTP(w, r)
	default:
		return
	}
}
