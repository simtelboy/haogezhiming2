# caddy-forwardproxy
A docker image for Caddy web server + forwardproxy plugin.
Allows to easily set up private web server with proxying.
### Build
```docker build -t caddy-forwardproxy .```
### Usage
Please find latest usage instructions in [run.sh](./run.sh).
